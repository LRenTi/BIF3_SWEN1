namespace MTCG;

/// <summary>
/// Represents the element type of a card.
/// </summary>
public enum ElementType
{
    Normal,
    Fire,
    Water
}
