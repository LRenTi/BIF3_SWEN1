namespace MTCG;

/// <summary>
/// Represents the type of a card.
/// </summary>
public enum CardType
{
    Monster,
    Spell
}